
import java.util.Scanner;

// 1. Elabore um algoritmo que leia um n�mero, e se ele for maior do que 20, imprimir esse n�mero na tela. 
public class exercicio1 {
	
	private static Scanner scanner;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int Num;
		
		System.out.print("Digite um n�mero:" );
		  scanner = new Scanner(System.in);
		Num = scanner.nextInt();
		  
		    if( Num > 20 )
		    	System.out.print(Num);
		    
		  
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		