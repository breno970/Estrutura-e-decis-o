
import java.util.Scanner;
 
public class exercicio4{


    public static void main(String[] args){       
        try (Scanner leitor = new Scanner(System.in)) {
			int n1, n2 ;
      

			System.out.println("Digite um n�mero");
			n1 = leitor.nextInt();
			System.out.println("Digite outro n�mero");
			n2 = leitor.nextInt();
			
     if(n1>n2) {
			  
				  System.out.println(n1+"\n"+n2);
     }
			  else {
				  System.out.println(n2+"\n"+n1);
			  }
		}
    }
}
    