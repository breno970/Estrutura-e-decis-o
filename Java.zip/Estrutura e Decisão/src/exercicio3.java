
import java.util.Scanner;
 
public class exercicio3 {


    public static void main(String[] args){       
        Scanner leitor = new Scanner(System.in);
        
        int num;
        
        System.out.println("escreva um n�mero e verifique se � positivo ou negativo");
        num = leitor.nextInt();
        
        if(num>0) {
        	System.out.println("Este nu�mero � positivo");
        }
        else {
        	System.out.println("Este n�mero � negativo");
        }
        
     }
}
