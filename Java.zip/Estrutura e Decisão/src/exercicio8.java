
import java.util.Scanner;

// 8. Elabore um algoritmo para testar se uma senha digita � igual a �AEDB�. Se a senha estiver correta escreva �Acesso permitido�, do contrario emita a mensagem �Voc� n�o tem acesso ao sistema�.

public class exercicio8 {
      
	 
	
	public static void main(String[] args) {
		
		try (Scanner ler = new Scanner(System.in)) {
			String nome;
			
			System.out.printf("\n\t Digite a senha:");
			nome = ler.next();
			


			
			       
			if(nome.equals("AEDB")){  
			       System.out.printf("\t Acesso permitido.");
			                 }  
			else { 
			           System.out.printf("\t Voc� n�o tem acesso a este sistema.");  
			      }
		}
		

	
		
		  }
	  }