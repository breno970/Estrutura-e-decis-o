
import java.util.Scanner;
//  Um comerciante comprou um produto e quer vend�-lo com um lucro de 45% se o valor da compra for menor que R$ 20,00; caso contr�rio, o lucro ser� de 30%. Elabore um algoritmo que leia o valor do produto e imprima o valor de venda para o produto. 
public class exercicio9 {

	
	public static void main(String[] args) {
		try (Scanner le = new Scanner(System.in)) {
			float valor;
			float por45, por30;
			
			System.out.printf("\t Digite o valor do produto:");
			valor = le.nextFloat();
			
			por45 = (((45*valor)/100) + valor);
			por30 = ((30 % valor) + valor);
			
			if(valor < 20) {  
			       System.out.printf("\t O valor de venda para o produto � de R$ %f", por45);  
			                 }  
			         else {  
			           System.out.printf("\t O valor de venda para o produto � de R$ %f", por30);  
			      }
		}
		
	
		
		

	}

}
