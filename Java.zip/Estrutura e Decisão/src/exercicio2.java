
import java.util.Scanner;
public class exercicio2 {
	

	
		public static void main(String[]args) {
			Scanner leitor = new Scanner(System.in);
			
		
			
			int n1;
			int n2 ;
			
			
			System.out.println("Escreva um n�mero");
			 n1 = leitor.nextInt();
			
			 System.out.println("Escreva outro n�mero");
			 n2 = leitor.nextInt();
			 
			 int soma = n1 + n2;
			 if(soma>10) {
				 System.out.print(soma);
			 System.out.println("sua soma � ="+soma);
			 
			 
			 
			 }

		}}